package com.mossle.bpm.expr;

public class Oper extends Token {
    public boolean isOper() {
        return true;
    }
}
