package com.mossle.bpm.expr;

public class Symb extends Token {
}
