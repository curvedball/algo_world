package com.mossle.api.party;

public interface PartyConnector {
    PartyDTO findById(String partyId);
}
