package com.mossle.api.user;

public interface ApplicationAliasConverter {
    String convertAlias(String type, String ip);
}
