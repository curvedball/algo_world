package com.mossle.auth.support;

public class CheckRoleException extends RuntimeException {
    public CheckRoleException(String message) {
        super(message);
    }
}
