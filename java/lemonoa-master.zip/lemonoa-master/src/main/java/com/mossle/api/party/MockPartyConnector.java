package com.mossle.api.party;

public class MockPartyConnector implements PartyConnector {
    public PartyDTO findById(String partyId) {
        return null;
    }
}
