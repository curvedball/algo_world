package com.mossle.api.process;

public class ProcessFormDTO {
}
