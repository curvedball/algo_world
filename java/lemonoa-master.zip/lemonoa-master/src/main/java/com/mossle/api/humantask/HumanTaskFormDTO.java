package com.mossle.api.humantask;

public class HumanTaskFormDTO {
}
