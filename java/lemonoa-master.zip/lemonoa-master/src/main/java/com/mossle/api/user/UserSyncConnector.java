package com.mossle.api.user;

public interface UserSyncConnector {
    void updateUser(UserDTO userDto);
}
