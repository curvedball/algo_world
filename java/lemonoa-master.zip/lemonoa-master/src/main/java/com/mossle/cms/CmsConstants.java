package com.mossle.cms;

public class CmsConstants {
    public static final int TYPE_TEXT = 0;
    public static final int TYPE_IMAGE = 1;
    public static final int TYPE_AUDIO = 2;
    public static final int TYPE_VIDEO = 3;
    public static final int TYPE_PDF = 4;
    public static final int TYPE_ETC = 5;
}
