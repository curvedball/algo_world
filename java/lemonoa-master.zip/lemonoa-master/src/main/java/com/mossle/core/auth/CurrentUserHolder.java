package com.mossle.core.auth;

public interface CurrentUserHolder {
    String getUserId();

    String getUsername();
}
