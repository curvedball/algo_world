package com.mossle.api.sequence;

import java.util.Date;

public class MockSequenceConnector implements SequenceConnector {
    public String generate(String code, String text) {
        return null;
    }

    public String generate(String code, String text, Date date) {
        return null;
    }
}
