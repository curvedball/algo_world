package com.mossle.api.user;

public interface AccountAliasConverter {
    String convertAlias(String alias);
}
