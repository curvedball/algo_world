package com.mossle.api.phrase;

import java.util.List;

public class MockPhraseConnector implements PhraseConnector {
    public List<String> findByUserId(String userId) {
        return null;
    }
}
