package com.mossle.auth.support;

public class CheckUserStatusException extends RuntimeException {
    public CheckUserStatusException(String message) {
        super(message);
    }
}
