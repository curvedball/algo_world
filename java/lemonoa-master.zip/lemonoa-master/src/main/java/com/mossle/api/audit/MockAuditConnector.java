package com.mossle.api.audit;

public class MockAuditConnector implements AuditConnector {
    public void log(AuditDTO auditDto) {
    }
}
