package com.mossle.api.sendsms;

public class MockSendsmsConnector implements SendsmsConnector {
    public void send(String to, String content, String tenantId) {
    }
}
