package com.mossle.api.msg;

public class MockMsgConnector implements MsgConnector {
    public void send(String subject, String content, String receiverId,
            String senderId) {
    }
}
