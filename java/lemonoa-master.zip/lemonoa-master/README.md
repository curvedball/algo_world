lemon
=====

[![Build Status](https://travis-ci.org/xuhuisheng/lemon.png)](https://travis-ci.org/xuhuisheng/lemon)

开源OA

http://www.mossle.com/
